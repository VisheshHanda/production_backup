// Copyright (c) 2017, Frappe Technologies Pvt. Ltd. and contributors
// For license information, please see license.txt

frappe.ui.form.on('Customs Tariff Number', {
	refresh: function(frm) {

	}
});
